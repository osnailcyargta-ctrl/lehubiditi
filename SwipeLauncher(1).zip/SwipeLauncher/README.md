# SwipeLauncher 🚀

Android launcher minimalis berbasis Kotlin dengan grid aplikasi + gyro wallpaper engine.

## Fitur

### Home Screen
- Grid app **NxN** (default 3×3) — bisa diubah ke 2×2, 4×4, 5×5
- **Swipe kiri/kanan** untuk pindah halaman
- **Swipe atas/bawah** atau klik tombol **All Apps** untuk buka full grid
- Dots indikator halaman

### Full Grid (`All Apps`)
- Semua app ditampilkan dalam grid NxN yang sama persis seperti home
- Swipe antar halaman
- Swipe ke bawah / tombol X untuk tutup

### Settings (⚙ icon pojok kiri bawah)
3 tab settings:

#### 🖼 Wallpaper
- Pilih gambar dari galeri sebagai wallpaper launcher (bukan wallpaper sistem)
- Toggle **Gyroscope Parallax** — wallpaper bergerak ikut sensor gyro

#### 📱 Display
- Grid size: 2×2, 3×3, 4×4, 5×5
- Ukuran font app label
- Font family: Default, Sans Serif, Serif, Monospace, Minecraft

#### ⚡ Misc
- Info versi
- **Secret panel** 🔒 — hanya muncul jika volume **0** saat buka tab ini
  - Pilih app yang mau disembunyikan dari launcher
  - App hidden tetap bisa diakses dari sini

## Build

### Requirements
- Android Studio Hedgehog atau lebih baru
- JDK 17+
- Android SDK 34

### Steps
```bash
git clone https://github.com/YOUR_USERNAME/SwipeLauncher.git
cd SwipeLauncher
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

### Set as Default Launcher
1. Install APK
2. Tekan tombol Home
3. Pilih **SwipeLauncher** → **Always**

## Tech Stack
- Kotlin
- ViewPager2 (swipe halaman)
- RecyclerView + GridLayoutManager
- Custom `GyroWallpaperView` (SensorEventListener + Canvas)
- SharedPreferences untuk semua settings
- Material Components
