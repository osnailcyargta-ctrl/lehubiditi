package com.swipelauncher.utils

import android.content.Context
import android.content.SharedPreferences

object PrefManager {
    private const val PREF_NAME = "swipe_launcher_prefs"
    private const val KEY_GRID_SIZE = "grid_size"
    private const val KEY_FONT_SIZE = "font_size"
    private const val KEY_FONT_FAMILY = "font_family"
    private const val KEY_WALLPAPER_URI = "wallpaper_uri"
    private const val KEY_GYRO_ENABLED = "gyro_enabled"
    private const val KEY_HIDDEN_APPS = "hidden_apps"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun getGridSize(context: Context): Int = prefs(context).getInt(KEY_GRID_SIZE, 3)
    fun setGridSize(context: Context, size: Int) = prefs(context).edit().putInt(KEY_GRID_SIZE, size).apply()

    fun getFontSize(context: Context): Float = prefs(context).getFloat(KEY_FONT_SIZE, 12f)
    fun setFontSize(context: Context, size: Float) = prefs(context).edit().putFloat(KEY_FONT_SIZE, size).apply()

    fun getFontFamily(context: Context): String = prefs(context).getString(KEY_FONT_FAMILY, "default") ?: "default"
    fun setFontFamily(context: Context, font: String) = prefs(context).edit().putString(KEY_FONT_FAMILY, font).apply()

    fun getWallpaperUri(context: Context): String? = prefs(context).getString(KEY_WALLPAPER_URI, null)
    fun setWallpaperUri(context: Context, uri: String?) = prefs(context).edit().putString(KEY_WALLPAPER_URI, uri).apply()

    fun isGyroEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_GYRO_ENABLED, false)
    fun setGyroEnabled(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(KEY_GYRO_ENABLED, enabled).apply()

    fun getHiddenApps(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_HIDDEN_APPS, emptySet()) ?: emptySet()

    fun setHiddenApps(context: Context, packages: Set<String>) =
        prefs(context).edit().putStringSet(KEY_HIDDEN_APPS, packages).apply()

    fun addHiddenApp(context: Context, packageName: String) {
        val current = getHiddenApps(context).toMutableSet()
        current.add(packageName)
        setHiddenApps(context, current)
    }

    fun removeHiddenApp(context: Context, packageName: String) {
        val current = getHiddenApps(context).toMutableSet()
        current.remove(packageName)
        setHiddenApps(context, current)
    }
}
