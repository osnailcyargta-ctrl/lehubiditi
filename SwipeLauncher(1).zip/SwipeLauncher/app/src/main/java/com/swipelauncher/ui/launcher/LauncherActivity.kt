package com.swipelauncher.ui.launcher

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GestureDetectorCompat
import androidx.viewpager2.widget.ViewPager2
import com.swipelauncher.R
import com.swipelauncher.data.AppInfo
import com.swipelauncher.databinding.ActivityLauncherBinding
import com.swipelauncher.ui.fullgrid.FullGridActivity
import com.swipelauncher.ui.settings.SettingsDialog
import com.swipelauncher.utils.AppLoader
import com.swipelauncher.utils.FontHelper
import com.swipelauncher.utils.PrefManager
import kotlin.math.abs

class LauncherActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLauncherBinding
    private lateinit var pageAdapter: PageAdapter
    private var apps: List<AppInfo> = emptyList()
    private var gridSize = 3
    private lateinit var gestureDetector: GestureDetectorCompat

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLauncherBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupGestureDetector()
        setupButtons()
        loadAndDisplay()
    }

    override fun onResume() {
        super.onResume()
        binding.wallpaperView.loadWallpaper()
        binding.wallpaperView.registerGyro()
        loadAndDisplay()
    }

    override fun onPause() {
        super.onPause()
        binding.wallpaperView.unregisterGyro()
    }

    private fun loadAndDisplay() {
        gridSize = PrefManager.getGridSize(this)
        val fontSize = PrefManager.getFontSize(this)
        val fontFamily = PrefManager.getFontFamily(this)
        val typeface = FontHelper.getTypeface(this, fontFamily)

        apps = AppLoader.loadApps(this)
        val perPage = gridSize * gridSize
        val pages = apps.chunked(perPage)

        if (!::pageAdapter.isInitialized) {
            pageAdapter = PageAdapter(
                pages, gridSize, fontSize, typeface,
                onAppClick = { launchApp(it) }
            )
            binding.viewPager.adapter = pageAdapter
            binding.viewPager.isUserInputEnabled = false // We handle swipe manually
        } else {
            pageAdapter.update(pages, gridSize, fontSize, typeface)
        }

        updateDots(pages.size, binding.viewPager.currentItem)
    }

    private fun setupGestureDetector() {
        gestureDetector = GestureDetectorCompat(this, object : GestureDetector.SimpleOnGestureListener() {
            private val SWIPE_THRESHOLD = 100
            private val SWIPE_VELOCITY = 100

            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent,
                velocityX: Float, velocityY: Float
            ): Boolean {
                val dx = e2.x - (e1?.x ?: 0f)
                val dy = e2.y - (e1?.y ?: 0f)

                if (abs(dx) > abs(dy)) {
                    // Horizontal swipe
                    if (abs(dx) > SWIPE_THRESHOLD && abs(velocityX) > SWIPE_VELOCITY) {
                        if (dx < 0) {
                            // Swipe left → next page
                            val next = binding.viewPager.currentItem + 1
                            if (next < pageAdapter.itemCount) {
                                binding.viewPager.setCurrentItem(next, true)
                                updateDots(pageAdapter.itemCount, next)
                            }
                        } else {
                            // Swipe right → prev page
                            val prev = binding.viewPager.currentItem - 1
                            if (prev >= 0) {
                                binding.viewPager.setCurrentItem(prev, true)
                                updateDots(pageAdapter.itemCount, prev)
                            }
                        }
                        return true
                    }
                } else {
                    // Vertical swipe
                    if (abs(dy) > SWIPE_THRESHOLD && abs(velocityY) > SWIPE_VELOCITY) {
                        if (dy < 0) {
                            // Swipe up → full grid
                            openFullGrid()
                        } else {
                            // Swipe down → full grid
                            openFullGrid()
                        }
                        return true
                    }
                }
                return false
            }
        })

        binding.root.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            false
        }
    }

    private fun setupButtons() {
        binding.btnFullGrid.setOnClickListener { openFullGrid() }
        binding.btnSettings.setOnClickListener { openSettings() }
    }

    private fun openFullGrid() {
        val intent = Intent(this, FullGridActivity::class.java)
        startActivity(intent)
        overridePendingTransition(R.anim.slide_up, 0)
    }

    private fun openSettings() {
        val dialog = SettingsDialog(this) {
            loadAndDisplay()
        }
        dialog.show()
    }

    private fun launchApp(app: AppInfo) {
        app.launchIntent?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
    }

    private fun updateDots(total: Int, current: Int) {
        binding.dotsContainer.removeAllViews()
        for (i in 0 until total) {
            val dot = View(this).apply {
                val size = 16
                val margin = 8
                val lp = android.widget.LinearLayout.LayoutParams(size, size).apply {
                    setMargins(margin, 0, margin, 0)
                }
                layoutParams = lp
                setBackgroundResource(
                    if (i == current) R.drawable.dot_active else R.drawable.dot_inactive
                )
            }
            binding.dotsContainer.addView(dot)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        return super.onTouchEvent(event)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == android.app.Activity.RESULT_OK) {
            val uri = data?.data?.toString()
            if (uri != null) {
                com.swipelauncher.ui.settings.WallpaperPickerBridge.pendingCallback?.invoke(uri)
                com.swipelauncher.ui.settings.WallpaperPickerBridge.pendingCallback = null
            }
        }
    }

    override fun onBackPressed() {
        // Launcher doesn't go back
    }
}
