package com.swipelauncher.wallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.util.AttributeSet
import android.view.View
import com.swipelauncher.utils.PrefManager
import kotlin.math.abs

class GyroWallpaperView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs), SensorEventListener {

    private var wallpaperBitmap: Bitmap? = null
    private val matrix = Matrix()
    private var offsetX = 0f
    private var offsetY = 0f
    private val maxOffset = 40f
    private var sensorManager: SensorManager? = null
    private var gyroSensor: Sensor? = null
    private var gyroEnabled = false

    init {
        loadWallpaper()
    }

    fun loadWallpaper() {
        val uri = PrefManager.getWallpaperUri(context)
        gyroEnabled = PrefManager.isGyroEnabled(context)
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(Uri.parse(uri))
                wallpaperBitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
            } catch (e: Exception) {
                wallpaperBitmap = null
            }
        } else {
            wallpaperBitmap = null
        }
        invalidate()
    }

    fun registerGyro() {
        if (!gyroEnabled) return
        sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        gyroSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        gyroSensor?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun unregisterGyro() {
        sensorManager?.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {
            val sensitivity = 3f
            offsetX += event.values[1] * sensitivity
            offsetY += event.values[0] * sensitivity
            offsetX = offsetX.coerceIn(-maxOffset, maxOffset)
            offsetY = offsetY.coerceIn(-maxOffset, maxOffset)
            // Dampen
            offsetX *= 0.95f
            offsetY *= 0.95f
            if (abs(offsetX) < 0.1f) offsetX = 0f
            if (abs(offsetY) < 0.1f) offsetY = 0f
            invalidate()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = wallpaperBitmap ?: return
        val vw = width.toFloat()
        val vh = height.toFloat()
        val bw = bmp.width.toFloat()
        val bh = bmp.height.toFloat()

        val scale = maxOf(vw / bw, vh / bh) * 1.1f // extra 10% for parallax room
        val scaledW = bw * scale
        val scaledH = bh * scale

        val baseX = (vw - scaledW) / 2f
        val baseY = (vh - scaledH) / 2f

        matrix.reset()
        matrix.setScale(scale, scale)
        matrix.postTranslate(baseX + offsetX, baseY + offsetY)
        canvas.drawBitmap(bmp, matrix, null)
    }
}
