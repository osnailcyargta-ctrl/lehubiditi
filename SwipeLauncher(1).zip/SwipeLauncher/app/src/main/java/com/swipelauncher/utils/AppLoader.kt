package com.swipelauncher.utils

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.swipelauncher.data.AppInfo

object AppLoader {

    fun loadApps(context: Context, includeHidden: Boolean = false): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val hiddenApps = PrefManager.getHiddenApps(context)
        val ownPackage = context.packageName

        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { resolveInfo ->
                val pkg = resolveInfo.activityInfo.packageName
                pkg != ownPackage && (includeHidden || !hiddenApps.contains(pkg))
            }
            .map { resolveInfo ->
                val pkg = resolveInfo.activityInfo.packageName
                val label = resolveInfo.loadLabel(pm).toString()
                val icon = resolveInfo.loadIcon(pm)
                val launchIntent = pm.getLaunchIntentForPackage(pkg)
                AppInfo(pkg, label, icon, launchIntent)
            }
            .sortedBy { it.label.lowercase() }
    }
}
