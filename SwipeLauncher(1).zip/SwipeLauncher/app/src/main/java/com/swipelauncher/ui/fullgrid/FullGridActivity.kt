package com.swipelauncher.ui.fullgrid

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GestureDetectorCompat
import androidx.viewpager2.widget.ViewPager2
import com.swipelauncher.R
import com.swipelauncher.data.AppInfo
import com.swipelauncher.databinding.ActivityFullGridBinding
import com.swipelauncher.ui.launcher.AppGridAdapter
import com.swipelauncher.ui.launcher.PageAdapter
import com.swipelauncher.utils.AppLoader
import com.swipelauncher.utils.FontHelper
import com.swipelauncher.utils.PrefManager
import kotlin.math.abs

class FullGridActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFullGridBinding
    private lateinit var pageAdapter: PageAdapter
    private lateinit var gestureDetector: GestureDetectorCompat

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFullGridBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnClose.setOnClickListener { finishWithAnim() }
        setupGesture()
        loadApps()
    }

    private fun loadApps() {
        val gridSize = PrefManager.getGridSize(this)
        val fontSize = PrefManager.getFontSize(this)
        val fontFamily = PrefManager.getFontFamily(this)
        val typeface = FontHelper.getTypeface(this, fontFamily)

        val apps = AppLoader.loadApps(this)
        val perPage = gridSize * gridSize
        val pages = apps.chunked(perPage)

        pageAdapter = PageAdapter(
            pages, gridSize, fontSize, typeface,
            onAppClick = { launchApp(it) }
        )
        binding.viewPager.adapter = pageAdapter
        binding.viewPager.isUserInputEnabled = true

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateDots(pages.size, position)
            }
        })

        updateDots(pages.size, 0)
    }

    private fun setupGesture() {
        gestureDetector = GestureDetectorCompat(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent,
                velocityX: Float, velocityY: Float
            ): Boolean {
                val dy = e2.y - (e1?.y ?: 0f)
                if (dy > 150 && abs(velocityY) > 100) {
                    finishWithAnim()
                    return true
                }
                return false
            }
        })
    }

    private fun launchApp(app: AppInfo) {
        app.launchIntent?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
        finish()
    }

    private fun finishWithAnim() {
        finish()
        overridePendingTransition(0, R.anim.slide_down)
    }

    private fun updateDots(total: Int, current: Int) {
        binding.dotsContainer.removeAllViews()
        for (i in 0 until total) {
            val dot = View(this).apply {
                val size = 16
                val margin = 8
                val lp = LinearLayout.LayoutParams(size, size).apply {
                    setMargins(margin, 0, margin, 0)
                }
                layoutParams = lp
                setBackgroundResource(
                    if (i == current) R.drawable.dot_active else R.drawable.dot_inactive
                )
            }
            binding.dotsContainer.addView(dot)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        return super.onTouchEvent(event)
    }

    override fun onBackPressed() {
        finishWithAnim()
    }
}
