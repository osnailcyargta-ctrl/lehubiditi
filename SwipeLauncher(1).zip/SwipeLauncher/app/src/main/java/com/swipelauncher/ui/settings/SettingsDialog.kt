package com.swipelauncher.ui.settings

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Window
import android.widget.*
import androidx.activity.result.ActivityResultLauncher
import com.swipelauncher.R
import com.swipelauncher.utils.FontHelper
import com.swipelauncher.utils.PrefManager

class SettingsDialog(
    context: Context,
    private val onDismiss: () -> Unit
) : Dialog(context) {

    private var wallpaperUri: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_settings)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setLayout(
            (context.resources.displayMetrics.widthPixels * 0.9).toInt(),
            android.view.WindowManager.LayoutParams.WRAP_CONTENT
        )

        setupTabs()
        setupWallpaperTab()
        setupDisplayTab()
        setupMiscTab()

        findViewById<Button>(R.id.btn_close_settings).setOnClickListener {
            dismiss()
            onDismiss()
        }
    }

    private fun setupTabs() {
        val tabWallpaper = findViewById<TextView>(R.id.tab_wallpaper)
        val tabDisplay = findViewById<TextView>(R.id.tab_display)
        val tabMisc = findViewById<TextView>(R.id.tab_misc)
        val contentWallpaper = findViewById<LinearLayout>(R.id.content_wallpaper)
        val contentDisplay = findViewById<LinearLayout>(R.id.content_display)
        val contentMisc = findViewById<LinearLayout>(R.id.content_misc)

        fun selectTab(tab: Int) {
            tabWallpaper.isSelected = tab == 0
            tabDisplay.isSelected = tab == 1
            tabMisc.isSelected = tab == 2
            contentWallpaper.visibility = if (tab == 0) android.view.View.VISIBLE else android.view.View.GONE
            contentDisplay.visibility = if (tab == 1) android.view.View.VISIBLE else android.view.View.GONE
            contentMisc.visibility = if (tab == 2) android.view.View.VISIBLE else android.view.View.GONE

            // Check secret: misc tab + volume 0
            if (tab == 2) checkSecretMisc()
        }

        tabWallpaper.setOnClickListener { selectTab(0) }
        tabDisplay.setOnClickListener { selectTab(1) }
        tabMisc.setOnClickListener { selectTab(2) }
        selectTab(0)
    }

    private fun setupWallpaperTab() {
        val btnPickWallpaper = findViewById<Button>(R.id.btn_pick_wallpaper)
        val switchGyro = findViewById<Switch>(R.id.switch_gyro)
        val tvWallpaperPath = findViewById<TextView>(R.id.tv_wallpaper_path)

        wallpaperUri = PrefManager.getWallpaperUri(context)
        switchGyro.isChecked = PrefManager.isGyroEnabled(context)
        tvWallpaperPath.text = if (wallpaperUri != null) "Wallpaper dipilih ✓" else "Belum ada wallpaper"

        btnPickWallpaper.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            // We use activity result via context casting
            if (context is android.app.Activity) {
                (context as android.app.Activity).startActivityForResult(intent, 1001)
            }
            // Store pending action - will be handled in activity
            WallpaperPickerBridge.pendingCallback = { uri ->
                try {
                    context.contentResolver.takePersistableUriPermission(
                        Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) {}
                wallpaperUri = uri
                PrefManager.setWallpaperUri(context, uri)
                tvWallpaperPath.text = "Wallpaper dipilih ✓"
            }
        }

        val btnClearWallpaper = findViewById<Button>(R.id.btn_clear_wallpaper)
        btnClearWallpaper.setOnClickListener {
            PrefManager.setWallpaperUri(context, null)
            wallpaperUri = null
            tvWallpaperPath.text = "Belum ada wallpaper"
        }

        switchGyro.setOnCheckedChangeListener { _, isChecked ->
            PrefManager.setGyroEnabled(context, isChecked)
        }
    }

    private fun setupDisplayTab() {
        val spinnerGrid = findViewById<Spinner>(R.id.spinner_grid_size)
        val seekFontSize = findViewById<SeekBar>(R.id.seek_font_size)
        val tvFontSize = findViewById<TextView>(R.id.tv_font_size_value)
        val spinnerFont = findViewById<Spinner>(R.id.spinner_font)

        // Grid size
        val gridOptions = listOf("2x2", "3x3", "4x4", "5x5")
        val gridValues = listOf(2, 3, 4, 5)
        val gridAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, gridOptions)
        gridAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerGrid.adapter = gridAdapter
        val currentGrid = PrefManager.getGridSize(context)
        spinnerGrid.setSelection(gridValues.indexOf(currentGrid).coerceAtLeast(0))
        spinnerGrid.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, pos: Int, id: Long) {
                PrefManager.setGridSize(context, gridValues[pos])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Font size
        val currentFontSize = PrefManager.getFontSize(context)
        seekFontSize.max = 24
        seekFontSize.progress = (currentFontSize - 8).toInt().coerceIn(0, 24)
        tvFontSize.text = "${currentFontSize.toInt()}sp"
        seekFontSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val size = (progress + 8).toFloat()
                PrefManager.setFontSize(context, size)
                tvFontSize.text = "${size.toInt()}sp"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Font family
        val fontLabels = FontHelper.FONTS.map { it.second }
        val fontKeys = FontHelper.FONTS.map { it.first }
        val fontAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, fontLabels)
        fontAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerFont.adapter = fontAdapter
        val currentFont = PrefManager.getFontFamily(context)
        spinnerFont.setSelection(fontKeys.indexOf(currentFont).coerceAtLeast(0))
        spinnerFont.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, pos: Int, id: Long) {
                PrefManager.setFontFamily(context, fontKeys[pos])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupMiscTab() {
        // Misc tab - normal content
        val tvMiscInfo = findViewById<TextView>(R.id.tv_misc_info)
        tvMiscInfo.text = "Misc Settings"
        // Secret panel hidden by default
        val secretPanel = findViewById<LinearLayout>(R.id.layout_secret)
        secretPanel.visibility = android.view.View.GONE
    }

    private fun checkSecretMisc() {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val volume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val secretPanel = findViewById<LinearLayout>(R.id.layout_secret)
        if (volume == 0) {
            secretPanel.visibility = android.view.View.VISIBLE
            loadHiddenAppsList()
        } else {
            secretPanel.visibility = android.view.View.GONE
        }
    }

    private fun loadHiddenAppsList() {
        val container = findViewById<LinearLayout>(R.id.hidden_apps_container)
        container.removeAllViews()
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val hiddenApps = PrefManager.getHiddenApps(context)
        val allApps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != context.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        allApps.forEach { resolveInfo ->
            val pkg = resolveInfo.activityInfo.packageName
            val label = resolveInfo.loadLabel(pm).toString()
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 8, 8, 8)
            }
            val cb = CheckBox(context).apply {
                text = label
                isChecked = hiddenApps.contains(pkg)
                setOnCheckedChangeListener { _, checked ->
                    if (checked) PrefManager.addHiddenApp(context, pkg)
                    else PrefManager.removeHiddenApp(context, pkg)
                }
            }
            row.addView(cb)
            container.addView(row)
        }
    }
}

object WallpaperPickerBridge {
    var pendingCallback: ((String) -> Unit)? = null
}
