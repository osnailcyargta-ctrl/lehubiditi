package com.swipelauncher.utils

import android.content.Context
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import com.swipelauncher.R

object FontHelper {

    val FONTS = listOf(
        "default" to "Default System",
        "sans_serif" to "Sans Serif",
        "serif" to "Serif",
        "monospace" to "Monospace",
        "minecraft" to "Minecraft"
    )

    fun getTypeface(context: Context, fontKey: String): Typeface? {
        return when (fontKey) {
            "default" -> null
            "sans_serif" -> Typeface.SANS_SERIF
            "serif" -> Typeface.SERIF
            "monospace" -> Typeface.MONOSPACE
            "minecraft" -> try {
                ResourcesCompat.getFont(context, R.font.minecraft)
            } catch (e: Exception) {
                null
            }
            else -> null
        }
    }
}
