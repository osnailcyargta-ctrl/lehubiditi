package com.swipelauncher.ui.launcher

import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.swipelauncher.R
import com.swipelauncher.data.AppInfo

class PageAdapter(
    private var pages: List<List<AppInfo>>,
    private var gridSize: Int,
    private var fontSize: Float,
    private var typeface: Typeface?,
    private val onAppClick: (AppInfo) -> Unit,
    private val onAppLongClick: (AppInfo) -> Unit = {}
) : RecyclerView.Adapter<PageAdapter.PageViewHolder>() {

    inner class PageViewHolder(val recyclerView: RecyclerView) : RecyclerView.ViewHolder(recyclerView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageViewHolder {
        val rv = RecyclerView(parent.context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        return PageViewHolder(rv)
    }

    override fun onBindViewHolder(holder: PageViewHolder, position: Int) {
        val pageApps = pages[position]
        val adapter = AppGridAdapter(
            pageApps, fontSize, typeface, onAppClick, onAppLongClick
        )
        holder.recyclerView.layoutManager = GridLayoutManager(holder.recyclerView.context, gridSize)
        holder.recyclerView.adapter = adapter
    }

    override fun getItemCount() = pages.size

    fun update(newPages: List<List<AppInfo>>, gridSize: Int, fontSize: Float, typeface: Typeface?) {
        this.pages = newPages
        this.gridSize = gridSize
        this.fontSize = fontSize
        this.typeface = typeface
        notifyDataSetChanged()
    }
}
