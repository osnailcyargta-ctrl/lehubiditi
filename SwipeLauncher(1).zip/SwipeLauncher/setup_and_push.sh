#!/bin/bash
# ============================================================
# SwipeLauncher - Setup & Push to GitHub
# Jalanin script ini di PC/Mac lo setelah extract zip ini
# ============================================================

GITHUB_TOKEN="ghp_n6dPYK1aED6P"
REPO_NAME="SwipeLauncher"

echo "🚀 SwipeLauncher GitHub Setup"
echo "================================"

# Get GitHub username from token
echo "Mengambil info akun GitHub..."
GH_USER=$(curl -s -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/user | python3 -c "import sys,json; print(json.load(sys.stdin)['login'])" 2>/dev/null)

if [ -z "$GH_USER" ]; then
    echo "❌ Gagal auth ke GitHub. Cek token lo."
    exit 1
fi

echo "✅ Login sebagai: $GH_USER"

# Create repo on GitHub
echo "Membuat repo $REPO_NAME..."
curl -s -H "Authorization: token $GITHUB_TOKEN" \
     -H "Content-Type: application/json" \
     -d "{\"name\":\"$REPO_NAME\",\"description\":\"Android launcher Kotlin - Grid NxN, Gyro Wallpaper, Secret Settings\",\"private\":false}" \
     https://api.github.com/user/repos > /dev/null

echo "✅ Repo dibuat: https://github.com/$GH_USER/$REPO_NAME"

# Init git and push
git init
git config user.email "launcher@swipe.dev"
git config user.name "$GH_USER"
git add -A
git commit -m "🚀 Initial commit - SwipeLauncher"
git branch -M main
git remote add origin "https://$GITHUB_TOKEN@github.com/$GH_USER/$REPO_NAME.git"
git push -u origin main

echo ""
echo "✅ Done! Repo lo: https://github.com/$GH_USER/$REPO_NAME"
echo ""
echo "📦 Build APK:"
echo "   ./gradlew assembleDebug"
echo "   APK: app/build/outputs/apk/debug/app-debug.apk"
